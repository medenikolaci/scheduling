﻿namespace proggeto
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.jobNameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.executionTimeTextBox = new System.Windows.Forms.TextBox();
            this.fifoRadioButton = new System.Windows.Forms.RadioButton();
            this.sjfRadioButton = new System.Windows.Forms.RadioButton();
            this.rrRadioButton = new System.Windows.Forms.RadioButton();
            this.addButton = new System.Windows.Forms.Button();
            this.executeButton = new System.Windows.Forms.Button();
            this.listBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // jobNameTextBox
            // 
            this.jobNameTextBox.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jobNameTextBox.Location = new System.Drawing.Point(126, 41);
            this.jobNameTextBox.Name = "jobNameTextBox";
            this.jobNameTextBox.Size = new System.Drawing.Size(120, 33);
            this.jobNameTextBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "NOME";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(296, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 33);
            this.label2.TabIndex = 2;
            this.label2.Text = "TEMPO";
            // 
            // executionTimeTextBox
            // 
            this.executionTimeTextBox.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.executionTimeTextBox.Location = new System.Drawing.Point(423, 41);
            this.executionTimeTextBox.Name = "executionTimeTextBox";
            this.executionTimeTextBox.Size = new System.Drawing.Size(120, 33);
            this.executionTimeTextBox.TabIndex = 3;
            // 
            // fifoRadioButton
            // 
            this.fifoRadioButton.AutoSize = true;
            this.fifoRadioButton.BackColor = System.Drawing.Color.DodgerBlue;
            this.fifoRadioButton.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fifoRadioButton.Location = new System.Drawing.Point(54, 170);
            this.fifoRadioButton.Name = "fifoRadioButton";
            this.fifoRadioButton.Size = new System.Drawing.Size(78, 32);
            this.fifoRadioButton.TabIndex = 4;
            this.fifoRadioButton.TabStop = true;
            this.fifoRadioButton.Text = "FIFO";
            this.fifoRadioButton.UseVisualStyleBackColor = false;
            // 
            // sjfRadioButton
            // 
            this.sjfRadioButton.AutoSize = true;
            this.sjfRadioButton.BackColor = System.Drawing.Color.DodgerBlue;
            this.sjfRadioButton.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sjfRadioButton.Location = new System.Drawing.Point(168, 170);
            this.sjfRadioButton.Name = "sjfRadioButton";
            this.sjfRadioButton.Size = new System.Drawing.Size(65, 32);
            this.sjfRadioButton.TabIndex = 5;
            this.sjfRadioButton.TabStop = true;
            this.sjfRadioButton.Text = "SJF";
            this.sjfRadioButton.UseVisualStyleBackColor = false;
            // 
            // rrRadioButton
            // 
            this.rrRadioButton.AutoSize = true;
            this.rrRadioButton.BackColor = System.Drawing.Color.DodgerBlue;
            this.rrRadioButton.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rrRadioButton.Location = new System.Drawing.Point(273, 170);
            this.rrRadioButton.Name = "rrRadioButton";
            this.rrRadioButton.Size = new System.Drawing.Size(170, 32);
            this.rrRadioButton.TabIndex = 6;
            this.rrRadioButton.TabStop = true;
            this.rrRadioButton.Text = "Round Robin";
            this.rrRadioButton.UseVisualStyleBackColor = false;
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.Color.Aqua;
            this.addButton.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton.Location = new System.Drawing.Point(588, 29);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(154, 55);
            this.addButton.TabIndex = 7;
            this.addButton.Text = "INSERISCI";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // executeButton
            // 
            this.executeButton.BackColor = System.Drawing.Color.Aqua;
            this.executeButton.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.executeButton.Location = new System.Drawing.Point(588, 147);
            this.executeButton.Name = "executeButton";
            this.executeButton.Size = new System.Drawing.Size(154, 55);
            this.executeButton.TabIndex = 8;
            this.executeButton.Text = "ESEGUI";
            this.executeButton.UseVisualStyleBackColor = false;
            this.executeButton.Click += new System.EventHandler(this.executeButton_Click_1);
            // 
            // listBox
            // 
            this.listBox.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 22;
            this.listBox.Location = new System.Drawing.Point(12, 220);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(776, 202);
            this.listBox.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.executeButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.rrRadioButton);
            this.Controls.Add(this.sjfRadioButton);
            this.Controls.Add(this.fifoRadioButton);
            this.Controls.Add(this.executionTimeTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.jobNameTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox jobNameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox executionTimeTextBox;
        private System.Windows.Forms.RadioButton fifoRadioButton;
        private System.Windows.Forms.RadioButton sjfRadioButton;
        private System.Windows.Forms.RadioButton rrRadioButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button executeButton;
        private System.Windows.Forms.ListBox listBox;
    }
}

