﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace proggeto
{
    public partial class Form1 : Form
    {

        private List<string> jobNomi = new List<string>();
        private List<int> jobExecutionTimes = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            string jobNome = jobNameTextBox.Text;
            string executionTimeString = executionTimeTextBox.Text;

            // Verifica che entrambi i campi siano stati compilati
            if (string.IsNullOrEmpty(jobNome) || string.IsNullOrWhiteSpace(executionTimeString))
            {
                listBox.Items.Add("Errore!!  Inserisci un nome e un tempo di esecuzione per il lavoro");
                return;
            }

            if(!int.TryParse(executionTimeString, out int executionTime) || executionTime <= 0)
            {
                listBox.Items.Add("Errore!! Il tempo di esecuzione deve essere un numero intero positivo");
                return;
            }

            if (jobNomi.Contains(jobNome))
            {
                listBox.Items.Add("Errore!! Questo nome lavoro è già stato utilizzato");
                return;
            }

            // Aggiungi il lavoro alla lista
            jobNomi.Add(jobNome);
            jobExecutionTimes.Add(executionTime);


            // Pulisci i campi di testo
            jobNameTextBox.Clear();
            executionTimeTextBox.Clear();

            listBox.Items.Add("Lavoto aggiunto con successo");
            listBox.Items.Add($"Nome: {jobNome}, Tempo di esecuzione: {executionTime} secondi");
        }
        private void executeButton_Click_1(object sender, EventArgs e)
        {
            // Verifica che sia stata selezionata una politica di scheduling
            if (!fifoRadioButton.Checked && !sjfRadioButton.Checked && !rrRadioButton.Checked)
            {
                listBox.Items.Add("Errore!! Seleziona solo una politica di scheduling");
                return;
            }

            // Esegui il lavoro in base alla politica di scheduling selezionata
            if (fifoRadioButton.Checked)
            {
                ExecuteFIFO();
            }
            else if (sjfRadioButton.Checked)
            {
                ExecuteSJF();
            }
            else if (rrRadioButton.Checked)
            {
                ExecuteRR();
            }
        }


        private void ExecuteFIFO()
        {

            listBox.Items.Add("FIFO-----------------");
            for (int i = 0; i< jobNomi.Count; i++)
            {
                listBox.Items.Add($"Inizio esecuzione del lavoro FIFO: {jobNomi[i]}\n Tempo di esecuzione: {jobExecutionTimes[i]} secondi");
                System.Threading.Thread.Sleep(jobExecutionTimes[i] * 1000);
                listBox.Items.Add($"Fine esecuzione del lavoro FIFO: {jobNomi[i]}");
            }
        }

        private void ExecuteSJF()
        {

            listBox.Items.Add("SJF------------------");
            List<int> sortedIndices = new List<int>();
            for(int i = 0;i< jobExecutionTimes.Count;i++)
            {
                sortedIndices.Add(i);
            }
            sortedIndices.Sort((x,y) => jobExecutionTimes[x].CompareTo(jobExecutionTimes[y]));

            foreach(int index in sortedIndices)
            {
                listBox.Items.Add($"Inizio esecuzione del lavoro SJF: {jobNomi[index]}\nTempo di esecuzione:{jobExecutionTimes[index]} secondi");
                System.Threading.Thread.Sleep(jobExecutionTimes[index] * 1000);
                listBox.Items.Add($"Fine essecuzione del lavoro SJF: {jobNomi[index]}");
            }
        }

        private void ExecuteRR()
        {

            listBox.Items.Add("RR-------------------");
            int rrQuantum = 5;

            for(int i = 0; i< jobNomi.Count; i++) 
            { 
                string jobNome = jobNomi[i];
                int executionTime = jobExecutionTimes[i];

                listBox.Items.Add($"Inizio esecuzione del lavoro RR: {jobNome}\n Tempo di esecuzione: {rrQuantum} secondi");
                System.Threading.Thread.Sleep(rrQuantum + 1000);

                int remainingTime = executionTime;
                if( remainingTime > 0 )
                {

                    listBox.Items.Add($"Fine esecuzione del lavoro RR: {jobNome}\n Tempo di esecuzione rimanente: {remainingTime} secondi");
                    System.Threading.Thread.Sleep (remainingTime * 1000);

                }
                else
                {
                    listBox.Items.Add($"Fine esecuzione del lavoro RR: {jobNome}");
                }
            }
        }

        
    }
}
